import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LaunchQuizComponent } from './launch-quiz.component';

describe('LaunchQuizComponent', () => {
  let component: LaunchQuizComponent;
  let fixture: ComponentFixture<LaunchQuizComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LaunchQuizComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LaunchQuizComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
