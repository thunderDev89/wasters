import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-launch-quiz',
  templateUrl: './launch-quiz.component.html',
  styleUrls: ['./launch-quiz.component.scss']
})
export class LaunchQuizComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
