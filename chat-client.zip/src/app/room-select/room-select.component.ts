import {Component, OnInit} from '@angular/core';
import {QuizService} from '../services/quiz.service';
import {Router} from '@angular/router';
import {Event} from '../model/event';
import {AuthService} from '../services/auth.service';

@Component({
  selector: 'app-room-select',
  templateUrl: './room-select.component.html',
  styleUrls: ['./room-select.component.scss']
})
export class RoomSelectComponent implements OnInit {

  isAuth = false;
  username: string;
  quizId;
  // private listener;

  constructor(private authService: AuthService,
              private quizService: QuizService,
              private router: Router) {
  }

  ngOnInit() {
    this.quizService.initSocket();
    this.onUserConnected();
    this.subscribeForQuiz();
  }

  private subscribeForQuiz() {
    this.quizService.onEvent(Event.QUIZ_SUBSCRIBED).subscribe(event => {
      this.router.navigate(['/quiz-launch']);
    });
  }

  connectAsUser() {
    if (!this.username) {
      this.authService.getUser(this.username).subscribe(user => {
        this.quizService.connectUser(user);
      });
    }
  }

  onQuizSubscribed(id) {
    this.quizService.subscribeForQuiz(id);

  }

  private onUserConnected() {
    this.quizService.onEvent(Event.USER_CONNECTED).subscribe( _ => {
      this.isAuth = true;
    });
  }
}
