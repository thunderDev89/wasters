import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { QuizListComponent } from './quiz/quiz-list/quiz-list.component';
import { QuizLaunchComponent } from './quiz/quiz-launch/quiz-launch.component';

const routes: Routes = [
  {path: '', component: AppComponent},
  {path: 'quizzes', component: QuizListComponent},
  {path: 'quizzes/:id', component: QuizLaunchComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
