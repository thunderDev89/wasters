import { Injectable } from '@angular/core';
import * as socketIo from 'socket.io-client';
import {User} from '../model/user.model';
import {Event} from '../model/event';
import {Observable} from 'rxjs';
import {Action} from '../model/action';

const SERVER_URL = 'http://localhost:8080';

@Injectable({
  providedIn: 'root'
})
export class QuizService {
  private user: User;
  private socket;
  constructor() { }

  initSocket(): void {
    this.socket = socketIo(SERVER_URL);
  }

  connectUser(user: User): void {
    this.user = user;
    this.socket.emit(Action.USER_CONNECT, user);
  }

  subscribeForQuiz(id) {
    const req = {quizzId: id};
    this.socket.emit(Action.CONNECT_QUIZ, req);
  }

  launchQuiz() {
    this.socket.emit(Action.LAUNCH_QUIZ);
  }

  checkData() {
    this.socket.emit(Action.CHECK_DATA);
  }

  public onEvent(event: Event): Observable<any> {
    return new Observable<any>(observer => {
      this.socket.on(event, () => observer.next());
    });
  }
}
