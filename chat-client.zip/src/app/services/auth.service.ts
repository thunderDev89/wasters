import {Injectable} from '@angular/core';
import {User} from '../model/user.model';
import {Observable, of} from 'rxjs';
import {USERS} from '../model/mock-data';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor() {
  }

  public getUser(name: string): Observable<User> {
    const user = USERS.find(u => u.from === name);
    return of(user);
  }
}
