export enum Action {
  USER_CONNECT = 'user_connect',
  CONNECT_QUIZ = 'connect_quiz',
  CHECK_DATA = 'check_data',
  LAUNCH_QUIZ = 'launch_quiz'
}
