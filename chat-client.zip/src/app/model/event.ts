export enum Event {
  CONNECT = 'connect',
  DISCONNECT = 'disconnect',
  QUIZ_SUBSCRIBED = 'quiz_subscribed',
  USER_CONNECTED = 'user_connected',
  QUESTION_TEASING = 'teasing_question',
  SELECT_ANSWERS = 'select_answers',
  HALT_QUESTION = 'halt_question'
}
