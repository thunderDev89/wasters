export class User {
  constructor(public from: string,
              public role: string) {}
}
