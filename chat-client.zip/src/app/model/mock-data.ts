import {Quiz} from './quiz.model';
import {User} from './user.model';

export const QUIZZES: Quiz[] = [
  {
    id: 1,
    name: 'Connais-tu le Cameroun ?',
    questions: [
      {
        title: 'Qui est le nouveau président du Cameroun?',
        answer1: 'Duncan',
        answer2: 'Kamto',
        answer3: 'Cabral',
        answer4: 'Joshua',
        rightAnswer: 1,
        duration: 5
      },
      {
        title: 'C\'est quoi la B.A.S ?',
        answer1: 'Bande d\'Assassins Salopards',
        answer2: 'La base',
        answer3: 'Brigade Anti Sardinards',
        answer4: 'Rien',
        rightAnswer: 3,
        duration: 5
      },
      {
        title: 'Y a-t-il une guere actuellement au Cameroun ?',
        answer1: 'Oui',
        answer2: 'Non',
        answer3: '',
        answer4: '',
        rightAnswer: 1,
        duration: 5
      },
      {
        title: 'Duncan va t-il mourir au pouvoir ?',
        answer1: 'Bien sûr que non',
        answer2: 'Evidemment',
        answer3: '',
        answer4: '',
        rightAnswer: 1,
        duration: 5
      },
    ]
  }
];

export const USERS: User[] = [
  new User('God', 'admin'),
  new User('riri', 'user'),
  new User('fifi', 'user'),
  new User('loulou', 'user'),
];
