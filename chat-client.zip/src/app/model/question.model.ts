export class Question {

    constructor(
        public title: string,
        public answer1: string,
        public answer2: string,
        public answer3: string,
        public answer4: string,
        public rightAnswer: number,
        public duration: number
    ) {}
}
