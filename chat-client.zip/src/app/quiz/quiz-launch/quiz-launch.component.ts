import { Component, OnInit, Input } from '@angular/core';
import { Question } from 'src/app/model/question.model';
import { ActivatedRoute } from '@angular/router';
import { QUIZZES } from 'src/app/model/mock-data';
import { interval } from 'rxjs';
import { take } from 'rxjs/operators';
import { Quiz } from 'src/app/model/quiz.model';

@Component({
  selector: 'app-quiz-launch',
  templateUrl: './quiz-launch.component.html',
  styleUrls: ['./quiz-launch.component.scss']
})
export class QuizLaunchComponent implements OnInit {

  quiz: Quiz;
  questionSelected: Question;
  currentQuestionId: number = 0;
  answerSelected: number = -1;
  disable: boolean = false;
  end: boolean = false;

  results = {
    correct: 0,
    wrong: 0,
    totalQuestions: 0
  }
  
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.displayQuiz();
    this.nextQuestion();
  }

  displayQuiz() {
    const id = this.route.snapshot.paramMap.get('id');
    this.quiz = QUIZZES.find(quiz => quiz.id === +id);

    this.results.totalQuestions = this.quiz.questions.length;
  }

  nextQuestion() {
    console.log("ID selected => "+ this.answerSelected);
    
    this.compileResult();

    if (this.currentQuestionId < this.results.totalQuestions) {
      this.questionSelected = this.quiz.questions[this.currentQuestionId++];
      console.log("questionSelected="+JSON.stringify(this.questionSelected));
      this.disable = false;
      this.answerSelected = -1;
    } else {
      this.end = true;
    }
  }

  onAnswerSelected(selection: number) {
    this.answerSelected = selection;
  }

  onHalt(stop: boolean) {
    this.disable = stop;
  }

  compileResult() {
    if (this.answerSelected > 0 && this.answerSelected < 4) {
      this.answerSelected === this.questionSelected.rightAnswer ? this.results.correct++ : this.results.wrong++;
    }
  }
}
