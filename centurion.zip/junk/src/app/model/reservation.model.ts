export class reservation {
    constructor(public begin: Date,
                public end: Date,
                public nb_rooms: number,
                public nb_guests: number,
                public name: string,
                public email: string,
                public phone: number) {}
}