export enum RoomType {
    SINGLE, DELUXE, ROYAL
}