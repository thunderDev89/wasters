import { RoomType } from "./room-type";

export class Room {
    constructor(public type: RoomType,
                public size: number,
                public max_guests: number,
                public nb_bedrooms: number,
                public nb_bathrooms: number,
                public has_balcony: boolean,
                public price_per_day: number){}
}