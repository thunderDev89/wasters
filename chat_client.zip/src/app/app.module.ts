import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuizListComponent } from './quiz/quiz-list/quiz-list.component';
import { QuizLaunchComponent } from './quiz/quiz-launch/quiz-launch.component';
import { QuestionsComponent } from './quiz/questions/questions.component';

@NgModule({
  declarations: [
    AppComponent,
    QuizListComponent,
    QuizLaunchComponent,
    QuestionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
