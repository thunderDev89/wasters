import { Component, OnInit } from '@angular/core';
import { Quiz } from 'src/app/model/quiz.model';
import { QUIZZES } from 'src/app/model/mock-data';

@Component({
  selector: 'app-quiz-list',
  templateUrl: './quiz-list.component.html',
  styleUrls: ['./quiz-list.component.scss']
})
export class QuizListComponent implements OnInit {

  quizzez: Quiz[];
  
  constructor() { }

  ngOnInit() {
    this.quizzez = QUIZZES;
  }

}
