import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Question } from 'src/app/model/question.model';
import { interval } from 'rxjs';
import { take } from 'rxjs/operators';
import { componentRefresh } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss']
})
export class QuestionsComponent implements OnInit {

  @Input() quizId: number;

  private _question: Question;
  // @Input() question: Question;
  secondes: number;

  @Output() answerSelected = new EventEmitter<number>();
  @Output() timeElapsed = new EventEmitter<boolean>();
  
  selected: number;
  disable: boolean = false;
  
  constructor() { }

  ngOnInit() {
    console.log("quiz id="+this.quizId);    
  }

  @Input()
  set question(question: Question) {
    this._question = question;

    this.refreshDisplay();
  }

  get question(): Question { return this._question; }

  onSelect(id: number) {
    this.selected = id;
    this.answerSelected.emit(id);
  }

  refreshDisplay() {
    this.selected = -1;
    this.disable = false;
    
    this.launchCounter();
  }

  launchCounter() {
    console.log("Countdown launched!");
    
    const counter = interval(1000).pipe(take(this.question.duration + 1));
    counter.subscribe(
      (value) => {
        this.secondes = this.question.duration - value;
      },
      (error) => {
        console.log("Error during the countdown");
      },
      () => {
        this.disable = true;
        this.timeElapsed.emit(true);
        console.log("Over : Time Elapsed !!!!!");
      }
    ); 
  }
}
